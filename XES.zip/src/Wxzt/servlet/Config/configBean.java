package Wxzt.servlet.Config;

/**
 * Created by Administrator on 2016-6-23.
 */
public class configBean {
    private String config;
    private String value;

    public void setConfig(String config){
        this.config = config;
    }
    public String getConfig(){
        return this.config;
    }

    public void setValue(String value){
        this.value = value;
    }
    public String getValue(){
        return this.value;
    }

}
