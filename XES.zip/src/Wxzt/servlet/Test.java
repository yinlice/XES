package Wxzt.servlet;

import Wxzt.servlet.Common.Query;

/**
 * Created by yin on 2017/3/29.
 */
public class Test extends Query {


}
