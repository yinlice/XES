package Wxzt.servlet.Report.javabean;

/**
 * Created by Administrator on 2016-9-12.
 */
public class HourBean {
    private String countCallIn;
    private String countCallOut;

    public String getCountCallIn() {
        return countCallIn;
    }
    public void setCountCallIn(String countCallIn) {
        this.countCallIn = countCallIn;
    }

    public String getCountCallOut() {
        return countCallOut;
    }
    public void setCountCallOut(String countCallOut) {
        this.countCallOut = countCallOut;
    }
}
