package Wxzt.servlet.Report.javabean;

/**
 * Created by Administrator on 2016-9-12.
 */
public class WorkBean {
    private String countCallIn;
    private String countCallInFail;
    private String countCallOut;
    private String countCallOutFail;
    private String timeLenIdle;
    private String onlineTime;
    private String callinTimeLenSpeak;
    private String calloutTimeLenSpeak;
    private String timeLenBusy;
    private String timeLenRest;
    private String timeLenEat;
    private String callinTimeLenRing;
    private String callIn;
    private String countSatisAgentNo;
    private String countSatisVery;
    private String countSatisGeneral;
    private String countSatisBad;
    private String countSatisCustNo;
    private String countCallOutEffective;

    public String getCountCallIn() {
        return countCallIn;
    }
    public void setCountCallIn(String countCallIn) {
        this.countCallIn = countCallIn;
    }
    public String getCountCallInFail() {
        return countCallInFail;
    }
    public void setCountCallInFail(String countCallInFail) {
        this.countCallInFail = countCallInFail;
    }
    public String getCountCallOut() {
        return countCallOut;
    }
    public void setCountCallOut(String countCallOut) {
        this.countCallOut = countCallOut;
    }
    public String getCountCallOutFail() {
        return countCallOutFail;
    }
    public void setCountCallOutFail(String countCallOutFail) {
        this.countCallOutFail = countCallOutFail;
    }
    public String getTimeLenIdle() {
        return timeLenIdle;
    }
    public void setTimeLenIdle(String TimeLenIdle) {
        this.timeLenIdle = TimeLenIdle;
    }
    public String getOnlineTime() {
        return onlineTime;
    }
    public void setOnlineTime(String onlineTime) {
        this.onlineTime = onlineTime;
    }
    public String getCallinTimeLenSpeak() {
        return callinTimeLenSpeak;
    }
    public void setCallinTimeLenSpeak(String callinTimeLenSpeak) {
        this.callinTimeLenSpeak = callinTimeLenSpeak;
    }
    public String getCalloutTimeLenSpeak() {
        return calloutTimeLenSpeak;
    }
    public void setCalloutTimeLenSpeak(String calloutTimeLenSpeak) {
        this.calloutTimeLenSpeak = calloutTimeLenSpeak;
    }
    public String getTimeLenBusy() {
        return timeLenBusy;
    }
    public void setTimeLenBusy(String timeLenBusy) {
        this.timeLenBusy = timeLenBusy;
    }
    public String getTimeLenRest() {
        return timeLenRest;
    }
    public void setTimeLenRest(String timeLenRest) {
        this.timeLenRest = timeLenRest;
    }
    public String getTimeLenEat() {
        return timeLenEat;
    }
    public void setTimeLenEat(String timeLenEat) {
        this.timeLenEat = timeLenEat;
    }
    public String getCallinTimeLenRing() {
        return callinTimeLenRing;
    }
    public void setCallinTimeLenRing(String callinTimeLenRing) {
        this.callinTimeLenRing = callinTimeLenRing;
    }
    public String getCallIn() {
        return callIn;
    }
    public void setCallIn(String callIn) {
        this.callIn = callIn;
    }
    public String getCountSatisAgentNo() {
        return countSatisAgentNo;
    }
    public void setCountSatisAgentNo(String countSatisAgentNo) {
        this.countSatisAgentNo = countSatisAgentNo;
    }
    public String getCountSatisVery() {
        return countSatisVery;
    }
    public void setCountSatisVery(String countSatisVery) {
        this.countSatisVery = countSatisVery;
    }
    public String getCountSatisGeneral() {
        return countSatisGeneral;
    }
    public void setCountSatisGeneral(String countSatisGeneral) {
        this.countSatisGeneral = countSatisGeneral;
    }
    public String getCountSatisBad() {
        return countSatisBad;
    }
    public void setCountSatisBad(String countSatisBad) {
        this.countSatisBad = countSatisBad;
    }
    public String getCountSatisCustNo() {
        return countSatisCustNo;
    }
    public void setCountSatisCustNo(String countSatisCustNo) {
        this.countSatisCustNo = countSatisCustNo;
    }

    public String getCountCallOutEffective() {
        return countCallOutEffective;
    }
    public void setCountCallOutEffective(String countCallOutEffective) {
        this.countCallOutEffective = countCallOutEffective;
    }
}
