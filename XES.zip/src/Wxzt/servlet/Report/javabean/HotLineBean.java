package Wxzt.servlet.Report.javabean;

/**
 * Created by Administrator on 2016-9-12.
 */
public class HotLineBean {
    private String countCallIn;
    private String countCallInFail;
    private String countCallOut;
    private String countCallOutFail;
    private String countCallInFailDtmf;
    private String countDTMF0;
    private String countDTMF1;
    private String countDTMF2;
    private String countDTMF3;
    private String countDTMF4;
    private String countDTMF5;
    private String countDTMF6;
    private String countDTMF7;
    private String countDTMF8;
    private String countDTMF9;
    private String countDTMFXing;
    private String countDTMFJing;
    private String countDTMFNo;

    public String getCountCallIn() {
        return countCallIn;
    }
    public void setCountCallIn(String countCallIn) {
        this.countCallIn = countCallIn;
    }
    public String getCountCallInFail() {
        return countCallInFail;
    }
    public void setCountCallInFail(String countCallInFail) {
        this.countCallInFail = countCallInFail;
    }
    public String getCountCallOut() {
        return countCallOut;
    }
    public void setCountCallOut(String countCallOut) {
        this.countCallOut = countCallOut;
    }
    public String getCountCallOutFail() {
        return countCallOutFail;
    }
    public void setCountCallOutFail(String countCallOutFail) {
        this.countCallOutFail = countCallOutFail;
    }
    public String getCountCallInFailDtmf() {
        return countCallInFailDtmf;
    }
    public void setCountCallInFailDtmf(String countCallInFailDtmf) {
        this.countCallInFailDtmf = countCallInFailDtmf;
    }
    public String getCountDTMF0() {
        return countDTMF0;
    }
    public void setCountDTMF0(String countDTMF0) {
        this.countDTMF0 = countDTMF0;
    }
    public String getCountDTMF1() {
        return countDTMF1;
    }
    public void setCountDTMF1(String countDTMF1) {
        this.countDTMF1 = countDTMF1;
    }
    public String getCountDTMF2() {
        return countDTMF2;
    }
    public void setCountDTMF2(String countDTMF2) {
        this.countDTMF2 = countDTMF2;
    }
    public String getCountDTMF3() {
        return countDTMF3;
    }
    public void setCountDTMF3(String countDTMF3) {
        this.countDTMF3 = countDTMF3;
    }
    public String getCountDTMF4() {
        return countDTMF4;
    }
    public void setCountDTMF4(String countDTMF4) {
        this.countDTMF4 = countDTMF4;
    }
    public String getCountDTMF5() {
        return countDTMF5;
    }
    public void setCountDTMF5(String countDTMF5) {
        this.countDTMF5 = countDTMF5;
    }
    public String getCountDTMF6() {
        return countDTMF6;
    }
    public void setCountDTMF6(String countDTMF6) {
        this.countDTMF6 = countDTMF6;
    }
    public String getCountDTMF7() {
        return countDTMF7;
    }
    public void setCountDTMF7(String countDTMF7) {
        this.countDTMF7 = countDTMF7;
    }
    public String getCountDTMF8() {
        return countDTMF8;
    }
    public void setCountDTMF8(String countDTMF8) {
        this.countDTMF8 = countDTMF8;
    }
    public String getCountDTMF9() {
        return countDTMF9;
    }
    public void setCountDTMF9(String countDTMF9) {
        this.countDTMF9 = countDTMF9;
    }
    public String getCountDTMFXing() {
        return countDTMFXing;
    }
    public void setCountDTMFXing(String countDTMFXing) {
        this.countDTMFXing = countDTMFXing;
    }
    public String getCountDTMFJing() {
        return countDTMFJing;
    }
    public void setCountDTMFJing(String countDTMFJing) {
        this.countDTMFJing = countDTMFJing;
    }
    public String getCountDTMFNo() {
        return countDTMFNo;
    }
    public void setCountDTMFNo(String countDTMFNo) {
        this.countDTMFNo = countDTMFNo;
    }
}
