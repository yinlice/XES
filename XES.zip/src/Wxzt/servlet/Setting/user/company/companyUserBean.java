package Wxzt.servlet.Setting.user.company;

/**
 * Created by Administrator on 2016-7-7.
 */
public class companyUserBean {
    private String workid;
    private String workname;
    private String worknum;
    private String sipnum;
    private String groupid;
    private String roleid;
    private String isWatch;
    private String note;
    private String mobile1;
    private String mobile2;
    private String email;
    private String passNumber;
    private String timeLenAutoRecovery;

    public void setWorkid(String workid){
        this.workid = workid;
    }
    public String getWorkid(){
        return this.workid;
    }

    public void setWorkname(String workname){
        this.workname = workname;
    }
    public String getWorkname(){
        return this.workname;
    }

    public void setWorknum(String worknum){
        this.worknum = worknum;
    }
    public String getWorknum(){
        return this.worknum;
    }

    public void setSipnum(String sipnum){
        this.sipnum = sipnum;
    }
    public String getSipnum(){
        return this.sipnum;
    }

    public void setGroupid(String groupid){
        this.groupid = groupid;
    }
    public String getGroupid(){
        return this.groupid;
    }

    public void setRoleid(String roleid){
        this.roleid = roleid;
    }
    public String getRoleid(){
        return this.roleid;
    }

    public void setIsWatch(String isWatch){
        this.isWatch = isWatch;
    }
    public String getIsWatch(){
        return this.isWatch;
    }

    public void setNote(String note){
        this.note = note;
    }
    public String getNote(){
        return this.note;
    }

    public void setMobile1(String mobile1){
        this.mobile1 = mobile1;
    }
    public String getMobile1(){
        return this.mobile1;
    }

    public void setMobile2(String mobile2){
        this.mobile2 = mobile2;
    }
    public String getMobile2(){
        return this.mobile2;
    }

    public void setEmail(String email){
        this.email = email;
    }
    public String getEmail(){
        return this.email;
    }

    public void setPassNumber(String passNumber){
        this.passNumber = passNumber;
    }
    public String getPassNumber(){
        return this.passNumber;
    }

    public void setTimeLenAutoRecovery(String timeLenAutoRecovery){
        this.timeLenAutoRecovery = timeLenAutoRecovery;
    }
    public String getTimeLenAutoRecovery(){
        return this.timeLenAutoRecovery;
    }
}
