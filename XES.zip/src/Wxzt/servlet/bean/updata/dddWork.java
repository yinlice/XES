package Wxzt.servlet.bean.updata;

/**
 * Created by Administrator on 2015/11/2.
 */
public class dddWork{
    private String worknum;
    private String workname;
    public String getWorknum() {
        return worknum;
    }
    public void setWorknum(String worknum) {
        this.worknum = worknum;
    }
    public String getWorkname() {
        return workname;
    }
    public void setWorkname(String workname) {
        this.workname = workname;
    }
}
