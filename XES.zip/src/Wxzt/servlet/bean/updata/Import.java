package Wxzt.servlet.bean.updata;

/**
 * Created by Administrator on 2015/11/23.
 */
public class Import {
    private String name;
    private String telnum;
    private String addr;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getTelnum() {
        return telnum;
    }
    public void setTelnum(String telnum) {
        this.telnum = telnum;
    }
    public String getAddr() {
        return addr;
    }
    public void setAddr(String addr) {
        this.addr = addr;
    }
}
