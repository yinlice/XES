package Wxzt.servlet.bean;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/11/13.
 */
public class queryBox {
    private String title;//用户姓名
    private String telNum;//用户电话

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    public String getTelNum() {
        return telNum;
    }
    public void setTelNum(String telNum) {
        this.telNum = telNum;
    }
}

