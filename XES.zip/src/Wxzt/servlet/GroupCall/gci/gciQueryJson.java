package Wxzt.servlet.GroupCall.gci;

import Wxzt.servlet.bean.Common.queryJson;

/**
 * Created by Administrator on 2016-10-19.
 */
public class gciQueryJson extends queryJson {
    protected String countType;//��ѯ���ݵ�����

    public String getCountType() {
        return countType;
    }
    public void setCountType(String countType) {
        this.countType = countType;
    }
}
