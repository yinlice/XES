package Wxzt.servlet.QueryReport;

/**
 * Created by yin on 2017/4/21.
 */
public class PersonTelBean {
    private int total;
    private int huru;
    private int huchu;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getHuru() {
        return huru;
    }

    public void setHuru(int huru) {
        this.huru = huru;
    }

    public int getHuchu() {
        return huchu;
    }

    public void setHuchu(int huchu) {
        this.huchu = huchu;
    }
}
