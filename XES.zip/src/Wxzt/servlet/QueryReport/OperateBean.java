package Wxzt.servlet.QueryReport;

/**
 * Created by yin on 2017/4/22.
 */
public class OperateBean {
    private String state;//状态
    private String time;//时间

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
