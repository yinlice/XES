package Wxzt.servlet.QueryReport;

import java.util.ArrayList;

/**
 * Created by yin on 2017/4/21.
 */
public class DoubleLineBean {
    private ArrayList list1;//用于存放日期
    private  ArrayList list2;//接通率
    private ArrayList list3;//满意度

    public ArrayList getList1() {
        return list1;
    }
    public void setList1(ArrayList list1) {
        this.list1 = list1;
    }
    public ArrayList getList2() {
        return list2;
    }
    public void setList2(ArrayList list2) {
        this.list2 = list2;
    }

    public ArrayList getList3() {
        return list3;
    }
    public void setList3(ArrayList list3) {
        this.list3 = list3;
    }
}
