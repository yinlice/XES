package Wxzt.servlet.QueryReport;

/**
 * Created by yin on 2017/4/21.
 */
public class PersonAverBean {
    //今日个人平均通话时长
    private int timelen;
    public int getTimelen() {
        return timelen;
    }
    public void setTimelen(int timelen) {
        this.timelen = timelen;
    }
}
