package Wxzt.servlet.QueryReport;

/**
 * Created by Administrator on 2017/2/6.
 */
public class HotLineBean {
    private String name;
    private int value;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getValue() {
        return value;
    }
    public void setValue(int value) {
        this.value = value;
    }
}
