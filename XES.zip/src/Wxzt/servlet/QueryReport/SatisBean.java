package Wxzt.servlet.QueryReport;

/**
 * Created by yin on 2017/4/21.
 */
public class SatisBean {
    private double manyidu;
    private int weipingjia;
    private int manyi;
    private int yiban;
    private int bumanyi;


    public double getManyidu() {
        return manyidu;
    }

    public void setManyidu(double manyidu) {
        this.manyidu = manyidu;
    }

    public int getWeipingjia() {
        return weipingjia;
    }

    public void setWeipingjia(int weipingjia) {
        this.weipingjia = weipingjia;
    }

    public int getManyi() {
        return manyi;
    }

    public void setManyi(int manyi) {
        this.manyi = manyi;
    }

    public int getYiban() {
        return yiban;
    }

    public void setYiban(int yiban) {
        this.yiban = yiban;
    }

    public int getBumanyi() {
        return bumanyi;
    }

    public void setBumanyi(int bumanyi) {
        this.bumanyi = bumanyi;
    }
}
