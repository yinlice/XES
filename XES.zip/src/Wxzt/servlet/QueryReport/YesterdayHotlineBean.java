package Wxzt.servlet.QueryReport;

import java.util.ArrayList;

/**
 * Created by yin on 2017/4/22.
 */
public class YesterdayHotlineBean {
    private ArrayList list1;//X轴坐标 (各个热线)
    private ArrayList list2;//送达量
    private ArrayList list3;//来话量
    private ArrayList list4;//接通量
    public ArrayList getList1() {
        return list1;
    }

    public void setList1(ArrayList list1) {
        this.list1 = list1;
    }

    public ArrayList getList2() {
        return list2;
    }

    public void setList2(ArrayList list2) {
        this.list2 = list2;
    }

    public ArrayList getList3() {
        return list3;
    }

    public void setList3(ArrayList list3) {
        this.list3 = list3;
    }

    public ArrayList getList4() {
        return list4;
    }

    public void setList4(ArrayList list4) {
        this.list4 = list4;
    }
}
