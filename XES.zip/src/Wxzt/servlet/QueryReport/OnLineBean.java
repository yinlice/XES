package Wxzt.servlet.QueryReport;

/**
 * Created by yin on 2017/4/21.
 */
public class OnLineBean{
    private int onLineTotal;
    private int eatTotal;
    private int xiaoxiuTotal;
    private int qianru;
    private int qianchu;

    public int getOnLineTotal() {
        return onLineTotal;
    }

    public void setOnLineTotal(int onLineTotal) {
        this.onLineTotal = onLineTotal;
    }

    public int getEatTotal() {
        return eatTotal;
    }

    public void setEatTotal(int eatTotal) {
        this.eatTotal = eatTotal;
    }

    public int getXiaoxiuTotal() {
        return xiaoxiuTotal;
    }

    public void setXiaoxiuTotal(int xiaoxiuTotal) {
        this.xiaoxiuTotal = xiaoxiuTotal;
    }

    public int getQianru() {
        return qianru;
    }

    public void setQianru(int qianru) {
        this.qianru = qianru;
    }

    public int getQianchu() {
        return qianchu;
    }

    public void setQianchu(int qianchu) {
        this.qianchu = qianchu;
    }
}
